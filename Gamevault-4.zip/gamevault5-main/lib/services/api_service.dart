import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/category.dart';

class ApiService {
  final String base = 'https://api.rawg.io/api';

  // Usamos la key de ejemplo para pruebas
  final String key = '7a1361e81c844fb9bb1884c5b5e8e2e5';

  Future<List<Category>> fetchCategories() async {
    final url = Uri.parse('$base/genres?key=$key');
    final res = await http.get(url);

    if (res.statusCode == 200) {
      final Map<String, dynamic> data = jsonDecode(res.body);
      final List<dynamic> items = data['results'] as List<dynamic>;
      return items
          .map((e) => Category.fromJson(e as Map<String, dynamic>))
          .toList();
    } else {
      throw Exception('Error al cargar categorías: ${res.statusCode}');
    }
  }
}

