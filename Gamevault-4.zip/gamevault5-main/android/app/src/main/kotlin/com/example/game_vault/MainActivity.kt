package com.example.game_vault

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
